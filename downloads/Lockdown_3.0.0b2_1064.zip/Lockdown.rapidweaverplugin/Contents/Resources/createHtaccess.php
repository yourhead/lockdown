

<?php
$filename=".htaccess";
$doExit=1;
if(file_exists($filename)) $doExit=0;


$__LCKDOWNPASSWDFILE__=getcwd() . "/__FILES__/_passwords";
	
if (ltrim(strstr($__LCKDOWNPASSWDFILE__," "))) {
		print "<H1>Unable to Configure This Account For Lockdown!</H1>";
		
		print "Your path of";
		print "<pre>".$__LCKDOWNPASSWDFILE__."</pre> has a space in it and will not work properly.  ";
		print "Please change your folder names and/or export name to remove the space and republish.";
		exit(1);
}
	
	


$someContent="__HTACCESS__" . chr(13) . "__ERRORACCESS__" .chr(13) ; // chr(13) is a carriage return -- Don't use \n as it breaks in Japanese

$handle=@fopen($filename,"w");
if ($handle!=false) {
	$myConvert=array_flip(get_html_translation_table(HTML_ENTITIES));

	
	$myUnEscapedContent= str_replace(array_keys($myConvert),array_values($myConvert),$someContent);
	
	fwrite($handle,$myUnEscapedContent);
	fclose($handle);
} else {

	if ($doExit) {
	$lockdownPasswdPath=getcwd() . "/__FILES__/_passwords";
	
	print "
<H1>Unable to Configure This Account For Lockdown!</H1>
<br>
I was unable to complete the configuration of this account, it is not locked down.
<br>
Please try configuring your account using these alternate instructions:

<br><ol>
<li>Go back to Rapidweaver and open the Lockdown page.</li>
<li>From this Lockdown page, select the passwords tab ->setup->Alternate Acct Configuration and put the following string in the 'Passwords File' field (but do not include the quotes)
</li></ol>
&quot;<b>" .$lockdownPasswdPath. "</b>&quot;
<br>
<ol start='3'>
<li>
a '.htaccess' box should appear, FTP to the location of the Lockdown page and drag & drop the '.htaccess' box to where this lockdown page is.
</li></ol>
";
	
	
	exit(1);
	}
}

if($doExit) {
    echo '<H1>Page should be locked down.  Refresh to Verify</H1>';
	echo "<h2>Browsers tend to remember username/passwords so you may need to completely exit the browser and come back in to get the prompt</h2>";
    echo "<H2>If you got this far and it still does not work then your server may not be configured to allow passwords, you can ask your web host to 'Allow Overrides' to fix this problem</h2>";
    exit(1);
}
?>


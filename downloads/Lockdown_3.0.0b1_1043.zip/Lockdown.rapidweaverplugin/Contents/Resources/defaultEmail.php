<?php

function preferredVal()
{
    $numberArgs=func_num_args();
    $i=0;
    for($i=0;$i<$numberArgs;$i++) {
        if (func_get_arg($i)!="")
            return func_get_arg($i);
    }
    return "";
	
}

$referrer=preferredVal($_SERVER["HTTP_REFERER"],$_ENV["HTTP_REFERER"],$HTTP_REFERER);
$thisPage=preferredVal($_SERVER["SCRIPT_URI"],$_ENV["SCRIPT_URI"],$SCRIPT_URI,$_SERVER["PHP_SELF"],$_SERVER["SCRIPT_NAME"]);
$remoteAddr=preferredVal($backa,$_SERVER["REMOTE_ADDR"],$_ENV["REMOTE_ADDR"],$REMOTE_ADDR);
$remoteUser=preferredVal( $_SERVER["REMOTE_USER"],$_ENV["REMOTE_USER"],$REDIRECT_REMOTE_USER,$_SERVER["REDIRECT_REMOTE_USER"]);
$userAgent=preferredVal($_ENV["HTTP_USER_AGENT"],$_SERVER["HTTP_USER_AGENT"],$HTTP_USER_AGENT);
$extraInfo=preferredVal($REDIRECT_QUERY_STRING,$QUERY_STRING,$_SERVER["REDIRECT_QUERY_STRING"]);
if($extraInfo!="")
   $extraInfoString="Extra Info Supplied: $extraInfo";

if ($remoteAddr!="")
$remoteHost=gethostbyaddr($remoteAddr);

if (function_exists(date_default_timezone_set))
	@date_default_timezone_set(date_default_timezone_get());

$time=date("r");

// $otherInfo=phpinfo();

$to="__TOEMAIL__";
$subject = "LockDown Page View $thisPage";
$body = "
Hello,

On $time

Someone with username: $remoteUser  
From: $remoteHost ( IP:$remoteAddr) http://www.dnsstuff.com/tools/ipall.ch?ip=$remoteAddr

Viewed the page $thisPage
They got here from $referrer

$extraInfoString

And were using the following browser $userAgent

$otherInfo

";
mail($to, $subject, $body);


?>


<?php
$filename=".htaccess";
if (file_exists($filename)) { 
	unlink($filename);
} 

?>

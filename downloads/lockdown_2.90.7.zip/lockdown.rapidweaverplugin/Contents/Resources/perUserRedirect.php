
<?php

function preferredValRedirect()
{
    $numberArgs=func_num_args();
    $i=0;
    for($i=0;$i<$numberArgs;$i++) {
        if (func_get_arg($i)!="")
            return func_get_arg($i);
    }
    return "";
	
}

$remoteUser=preferredValRedirect( $_SERVER["REMOTE_USER"],$_ENV["REMOTE_USER"],$_SERVER["REDIRECT_REMOTE_USER"],$_SERVER["PHP_AUTH_USER"]);

__PER_USER_REDIRECT__

?>

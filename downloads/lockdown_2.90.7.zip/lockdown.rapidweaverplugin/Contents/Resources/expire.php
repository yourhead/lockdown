

<?php


/* This is the magic function that we want to duplicate for all people who don't have expireDates in the 'distantFuture' */

// Syntax is like this: checkUser("sam",1142751386);

$shouldDie=0; // default to no die

//__CHECKUSERS__

if ($shouldDie)
    die();


function checkUser($myUser,$expireDateEpoch) {
	global $shouldDie;
	if (function_exists(date_default_timezone_set))
		@date_default_timezone_set(date_default_timezone_get());
	if (time() > $expireDateEpoch) { // time since Epoch
		removeUser($myUser);
		if (getUserName()==$myUser) {
			echo "<h2>User <b>'$myUser'</b> is no longer Authorized!</h2>\n";
			$shouldDie=1;
        }
    }
}





function removeUser($userName) { // Remove a user from the password file....
	
	$passwdFileName="__FILES__/_passwords";
	$newPasswdFileName="__FILES__/_newPasswords";
	
	$newPasswdFile=@fopen($newPasswdFileName,"w+");
	
	if ($newPasswdFile==FALSE) return; // if we can't open a file don't even try since this account
									   // doesn't support the proper permissions
	$passwdFile=fopen($passwdFileName,"r");
	
	while(!feof($passwdFile)) {
		$buffer=fgets($passwdFile);
		list($user,$pass)=split(":",$buffer,2);
		if(!strcmp($user,$userName)==0) {
			fwrite($newPasswdFile,$buffer);
		} else {
			// echo "Found User $userName! $user, $pass";
		}
	}
	
	fclose($passwdFile);
	fclose($newPasswdFile);
	
	rename($newPasswdFileName,$passwdFileName); // atomically move the subdirectory
}

function getUserName()
{
	
    if ($_SERVER["REMOTE_USER"]!="")
        return $_SERVER["REMOTE_USER"];
    if ($_ENV["REMOTE_USER"]!="")
        return $_ENV["REMOTE_USER"];
    return "unknown";
}

?>


